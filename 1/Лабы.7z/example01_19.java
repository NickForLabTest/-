public class example01_19{
    static double a=10.0,b=4.0,c;
    public static double hyp(double First, double Second){
        return c=Math.sqrt(First*First+Second*Second);
    }

    public static void main(String args[]){
        System.out.println("katet a=" + a); 
        System.out.println("katet b=" + b); 
        System.out.println("hypotenuse c=" + hyp(a,b));

    }
}