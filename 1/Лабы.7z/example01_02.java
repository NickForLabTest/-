public class example01_02{ 
    public static void main(String args[]) 
    { 
    int num; 
    num = 100;
    System.out.println("num: " + num); 
    num = num * 2; 
    System.out.print("Znachenie num * 2 equal "); 
    System.out.println(num); 
    } 
    }